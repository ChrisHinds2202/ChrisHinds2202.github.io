# Christopher Hinds
# 11 Nov 25
# P4LAB1B
# using turtle to draw my initialas 'C' and 'H'

import turtle

t = turtle.Turtle()

#draw 'C"
t.pensize(10)
t.color("purple")
t.back(40)
t.circle(90, -180)
t.back(40)
t.penup()

#draw 'H'
t.goto(-50, 0)
t.pendown()
t.left(90)
t.forward(200)
t.left(180)
t.forward(100)
t.right(90)
t.forward(75)
t.left(90)
t.forward(100)
t.left(180)
t.forward(200)