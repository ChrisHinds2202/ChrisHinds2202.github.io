# Christopher Hinds
# 11 Nov 25
# P4LAB1A
# using turtle to draw a scare and triangle usuing loops 



import turtle

turtle = turtle.Turtle()

#user input for length of square sides
s = int(input("How long do you wnat the length of the square?: "))

for i in range(4):
    turtle.forward(s)
    turtle.speed(2)
    turtle.left(90)

#user input for length of traingle sides
l = int(input("How long do you wnat the length of the triangle?: "))

num = 0

while num < 3:
    turtle.forward(l)
    turtle.speed(2)
    turtle.right(120)
    num += 1


